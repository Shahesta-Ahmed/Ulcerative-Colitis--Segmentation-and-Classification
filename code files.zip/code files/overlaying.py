from PIL import Image
import os

def overlay_mask(image_path, mask_path, output_path, alpha=0.5):
    # Open the image and mask
    image = Image.open(image_path).convert("RGBA")
    mask = Image.open(mask_path).convert("RGBA")

    # Resize mask to match the image size
    mask = mask.resize(image.size)

    # Blend the images using alpha parameter
    overlay = Image.blend(image, mask, alpha)

    # Save the result
    overlay.save(output_path, "PNG")

def overlay_masks_in_folder(image_folder, mask_folder, output_folder, alpha=0.5):
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Get the list of classes (subfolders) in the image folder
    classes = [class_folder for class_folder in os.listdir(image_folder) if os.path.isdir(os.path.join(image_folder, class_folder))]

    for class_folder in classes:
        class_image_folder = os.path.join(image_folder, class_folder)
        class_mask_folder = os.path.join(mask_folder, class_folder)
        class_output_folder = os.path.join(output_folder, class_folder)

        # Create class output folder if it doesn't exist
        os.makedirs(class_output_folder, exist_ok=True)

        # Get the list of images in the class folder
        images = [image for image in os.listdir(class_image_folder) if image.endswith('.jpg')]

        for image_name in images:
            image_path = os.path.join(class_image_folder, image_name)
            mask_path = os.path.join(class_mask_folder, image_name)
            output_path = os.path.join(class_output_folder, image_name.replace('.jpg', '.png'))

            # Check if the file is an image (ends with .jpg)
            if os.path.isfile(image_path) and os.path.isfile(mask_path):
                # Overlay the mask on the image with alpha blending
                overlay_mask(image_path, mask_path, output_path, alpha=alpha)

if __name__ == "__main__":
    image_folder = "/Users/shahestaahmed/Documents/ulcerative_colitis/data"
    mask_folder = "/Users/shahestaahmed/Documents/ulcerative_colitis/masks"
    output_folder = "/Users/shahestaahmed/Documents/ulcerative_colitis/uc"

    overlay_masks_in_folder(image_folder, mask_folder, output_folder)
